/*global
    angular
 */
angular.module('starter').config(function($stateProvider) {
    $stateProvider
        .state('taxi_ride-tco', {
            url: BASE_PATH + "/taxiride/mobile_view/tco/value_id/:value_id/request_id/:request_id",
            controller: 'TaxiRideTcoController',
            templateUrl: "modules/taxi_ride/templates/l1/creditcard-form.html"
        });
}).controller('TaxiRideTcoController', function($ionicHistory, $ionicViewSwitcher, $scope, $stateParams,
                                                $state, $timeout, $translate, Loader, Customer, Dialog, TaxiRide) {

    $scope.value_id = TaxiRide.value_id = $stateParams.value_id;
    $scope.request_id = $stateParams.request_id;

    $scope.card = {};

    $scope.loading = function() {
        Loader.show($translate.instant($translate.instant("Loading")+"...") +
            "<br/><br/><ion-spinner class=\"spinner-custom\"></ion-spinner>", {}, true);
    };

    $scope.loadContent = function() {
        $scope.loading();

        $scope.page_title = $translate.instant("Pay online");

        if(typeof TCO == "undefined") {
            $scope.is_loading = true;
            var tcoJS = document.createElement('script');
            tcoJS.type = "text/javascript";
            tcoJS.src = "https://www.2checkout.com/checkout/api/2co.min.js";
            tcoJS.onload = function() {
                $timeout(function() {
                    $scope.initTCO();
                });
            };
            document.body.appendChild(tcoJS);
        } else {
            $scope.initTCO();
        }

    };

    $scope.initTCO = function() {
        TCO.loadPubKey('sandbox', function() {
            TaxiRide.tco.getConfig($scope.request_id)
                .success(function(data) {
                     $scope.tco_config = data;
                }).error(function() {
                    Dialog.alert('Error', 'Error while retrieving 2Checkout configuration from server.', 'OK', -1);
                }).finally(function() {
                    Loader.hide();
                    $scope.is_loading = false;
                });
        });
    };

    $scope.tokenRequest = function() {

        $scope.is_loading = true;
        $scope.loading();

        if($scope.card.exp_year > 0 && $scope.card.exp_year < 100) {
            $scope.card.exp_year += 2000;
        }

        var error_messages = [];

        if(!($scope.card.number > 0)) {
            error_messages.push($translate.instant("Please enter a credit card number"));
        }

        if(!($scope.card.exp_month > 0)) {
            error_messages.push($translate.instant("Please enter the credit card expiration month"));
        }

        if(!($scope.card.exp_year > 0)) {
            error_messages.push($translate.instant("Please enter the credit card expiration year"));
        }

        if(error_messages.length > 0) {
            Dialog.alert('', error_messages.shift(), 'OK', -1);

            $scope.is_loading = false;
            Loader.hide();
            return;
        }
        // Setup token request arguments
        var args = {
            sellerId: $scope.tco_config.sid,
            publishableKey: $scope.tco_config.publishable_key,
            ccNo: $scope.card.number.toString(),
            cvv: $scope.card.cvc.toString(),
            expMonth: $scope.card.exp_month.toString(),
            expYear: $scope.card.exp_year.toString()
        };

        // Make the token request
        TCO.requestToken($scope.successCallback, $scope.errorCallback, args);
    };

    $scope.successCallback = function(data) {

        Loader.hide();
        $scope.loading();

        TaxiRide.tco.processTransaction(data.response.token.token, $scope.tco_config.price, $scope.request_id).success(function(data) {
            $state.go("taxi_ride-view", {"value_id": $scope.value_id});
        }).error(function(data) {
            Dialog.alert('Error', data.error_message, 'OK', -1);
        }).finally(function() {
            $scope.is_loading = false;
            Loader.hide();
        });
    };

    $scope.errorCallback = function(data) {
        Dialog.alert('Error', data.errorMsg, 'OK', -1);
        $scope.is_loading = false;
        Loader.hide();
    };

    $scope.is_loading = true;
    $scope.loadContent();

});
