/*global
    angular, DOMAIN
 */
angular.module('starter')
    .controller('TaxiRideEstimateRideModalController', function ($scope, $translate, $timeout, TaxiRide, Dialog) {
    $scope.currency_symbol = TaxiRide.currency_symbol;

    $scope.info = {
        'step_1': true,
        'step_2': false,
        'type_choice': null,
        'payment_choice': null
    };

    TaxiRide.getVehiculeTypes().then(function (data) {
        $scope.vehicule_list = _.map(data, function (vt) {
            return _.extend(
                {},
                vt,
                {
                    picture: ((_.isString(_.get(vt, 'picture')) && vt.picture.length > 0) ? (DOMAIN + '/' + vt.picture) : null)
                }
            );
        });
    });

    $scope.validateVehiculeType = function () {
        if ($scope.info.type_choice) {
            $scope.info.step_1 = false;
            $scope.info.step_2 = true;

            TaxiRide.getDriversAroundLocation($scope.ride.pickup_lat, $scope.ride.pickup_long, $scope.info.type_choice)
                .success(function (data) {
                    $scope.available_drivers = data.drivers;
                    $scope.no_driver_available = !$scope.available_drivers.length;
                    $scope.available_methods = data.payment_method;
                    $scope.tco_available = TaxiRide.tco_available;
                    $scope.stripe_available = TaxiRide.stripe_available;

                    $scope.min_estimate = 9999;
                    $scope.max_estimate = 0;

                    _.forEach($scope.available_drivers, function (driver) {
                        var driverFare;
                        if (driver.distance_fare) {
                            driverFare = parseFloat(driver.base_fare) +
                                driver.distance_fare * ($scope.ride.route.legs[0].distance.value/1000);
                        } else {
                            driverFare = parseFloat(driver.base_fare) +
                                driver.time_fare * ($scope.ride.route.legs[0].duration.value/60);
                        }

                        if (driverFare < $scope.min_estimate) {
                            $scope.min_estimate = parseFloat(driverFare).toFixed(2);
                        }

                        if (driverFare > $scope.max_estimate) {
                            $scope.max_estimate = parseFloat(driverFare).toFixed(2);
                        }
                    });
                });
        } else {
            // should be 'Please select a vehicle type'
            Dialog.alert('', 'Please choose a vehicle type', 'OK', -1);
        }
    };

    $scope.validateRequest = function () {
        if ($scope.info.payment_choice) {
            var request = {
                'pickup_address': $scope.ride.pickup_address,
                'pickup_lat': $scope.ride.pickup_lat,
                'pickup_long': $scope.ride.pickup_long,
                'dropoff_address': $scope.ride.dropoff_address,
                'dropoff_lat': $scope.ride.dropoff_lat,
                'dropoff_long': $scope.ride.dropoff_long,
                'payment_method': $scope.info.payment_choice
            };

            TaxiRide.passenger.makeRequest(request, $scope.info.type_choice)
                .then(function (data) {
                    if (data.success) {
                        TaxiRide.showDriverWaitingModal(data.request);
                        $scope.close();
                    } else {
                        // should be 'An error occured while sending your request. Please try again later.'
                        Dialog.alert('', 'An error occured while lauching your request. Please try again later.', 'OK', -1);
                    }
                });
        } else {
            // should be 'Please select a payment method'
            Dialog.alert('', 'Please choose a payment method', 'OK', -1);
        }
    };

    $scope.close = function () {
        $scope.$close();
    };
});
