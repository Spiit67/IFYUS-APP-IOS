/*global
    angular
*/
angular.module('starter')
    .controller('TaxiRideDriverWaitingModalController', function ($interval, $scope, $timeout, $translate,
                                                                 TaxiRide, Loader) {
    $scope.init = function () {
        $scope.currency_symbol = TaxiRide.currency_symbol;
        $scope.prices_disclamer = TaxiRide.prices_disclamer;
        $scope.original_scope.has_launched_request = false;
        $scope.is_looking_for_drivers = true;
        $scope.no_driver_answer = false;
        $scope.drivers = [];
        $scope.timer = TaxiRide.search_timeout;
        $scope.can_select_driver = true;
    };

    $scope.init();

    var searchInterval = $interval(function () {
        $scope.updateTimer();
    }, 1000);
    var selectInterval = null;

    $scope.updateTimer = function () {
        if ($scope.timer > 0) {
            $scope.timer = $scope.timer - 1;
        } else {
            $interval.cancel(searchInterval);
            $scope.is_looking_for_drivers = false;
            if (!$scope.drivers.length) {
                $scope.no_driver_answer = true;
            } else {
                $scope.select_timer = TaxiRide.search_timeout;
                selectInterval = $interval(function () {
                    $scope.updateSelectTimer();
                }, 1000);
            }
        }
    };

    $scope.updateSelectTimer = function () {
        if ($scope.select_timer > 0) {
            $scope.select_timer = $scope.select_timer - 1;
        } else {
            $interval.cancel(selectInterval);
            $scope.can_select_driver = false;
            TaxiRide.updateStatus($scope.request, 'cancelled');
        }
    };

    $scope.$on(TaxiRide.DRIVER_ACCEPTED_REQUEST, function (event, driver, request) {
        driver.request = request;
        $scope.drivers.push(driver);
    });

    // Trying to disable request while requesting!
    $scope.disableSelectDriver = false;
    $scope.selectDriver = function (driver) {
        if (!$scope.disableSelectDriver) {
            $scope.disableSelectDriver = true;
            Loader.show(
                $translate.instant('Sending request') + '...<br/><br/><ion-spinner class="spinner-custom"></ion-spinner>',
                {},
                true
            );
            $timeout(function () {
                Loader.hide();
                $scope.disableSelectDriver = false;
            }, 15000);
            TaxiRide.passenger.acceptRequest(driver.request, driver)
                .then(function () {
                    $scope.original_scope.has_launched_request = true;
                    $scope.close();
                    $scope.disableSelectDriver = false;
                });
        }
    };

    $scope.close = function () {
        if (searchInterval) {
            $interval.cancel(searchInterval);
        }
        if (selectInterval) {
            $interval.cancel(selectInterval);
        }
        $scope.$close();
    };
});
